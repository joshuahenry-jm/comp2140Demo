import java.util.List;
import java.util.Iterator;

public class StockManager {

    // List to hold menu items
    private List <MenuItem> menuItems;

    // Reference to QueueManager
    private final QueueManager queueManager;

    // Reference to NotificationService (optional)
    //private final NotificationService notificationService;

    // Constructor , NotificationService notificationService
    public StockManager(List<MenuItem> menuItems, QueueManager queueManager) {
        this.menuItems = menuItems;
        this.queueManager = queueManager;   
       // this.notificationService = notificationService;
    }

    /*  Check if all items in an order have enough stock
    public boolean CheckStock(Order order) {
        for (MenuItem orderItem : order.getMenuItems()) {
            boolean itemFound = false;

            for (MenuItem menuItem : menuItems) {
                if (menuItem.getName().equals(orderItem.getName())) {
                    itemFound = true;

                    if (menuItem.getStock() < menuItem.getQuantity()) {
                        return false; // Not enough stock
                    }
                    break;
                }
            }

            if (!itemFound) {
                return false; // Item not in menu
            }
        }

        return true; // All good
    }
*/

    // Helper to remove unavailable orders
    private void cancelOutOfStockOrders(List<Order> orders) {
        Iterator<Order> it = orders.iterator();

        while (it.hasNext()) {
            Order order = it.next();

            /*if (!isItemAvailable(order)) {
                it.remove();

                if (notificationService != null) {
                    notificationService.notifyCancellation(order);
                
            }}*/
        }
    }
}