import java.util.ArrayList;



public class MenuItem {
    private String name,ingredients;
    private double price;
    private int prepTime;
    private int itemID;
    Menu menu;
    //private static int stockQuantity = 0;
    


    public MenuItem (String name, double price, int prepTime, int itemID) {
        this.name = name;
        this.price = price;
        this.prepTime = prepTime;
        this.itemID = itemID;

        Menu.addMenuItem(this);
        
    }

    public MenuItem (String name, String ingredients, double price, int prepTime, int itemID) {
        this.name = name;
        this.ingredients = ingredients;
        this.price = price;
        this.prepTime = prepTime;
        this.itemID = itemID;

        Menu.addMenuItem(this);
        
    }

    public MenuItem() {
        
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getPrepTime() {
        return prepTime;
    }

    public int getItemID() {
        return itemID;
    }

    public String getIngredients() {
        return ingredients;
    }


    



}